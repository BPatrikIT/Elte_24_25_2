#ifndef DRAWTOWER_H
#define DRAWTOWER_H

void drawTower(int *tower, int diskNumber);

#endif