#ifndef GENERATETOWER_H
#define GENERATETOWER_H

int *GenerateTower(int N);

#endif