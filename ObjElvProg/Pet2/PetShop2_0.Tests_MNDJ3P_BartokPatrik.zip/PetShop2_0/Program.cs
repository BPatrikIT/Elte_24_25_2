﻿namespace PetShop2_0
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
