﻿using System.Globalization;

namespace PetShop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
