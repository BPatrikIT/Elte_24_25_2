﻿public class FileSystem
{
    // Üres osztály, jelenleg nincs benne semmi
}