﻿public abstract class Registration
{
    public abstract int GetSize();
}